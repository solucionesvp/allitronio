import { NextRequest, NextResponse } from "next/server";
import { getFinanzasSupabase } from "@/lib/supabaseFinanzas";
import { getFinanzasRole, getFinanzasPersona, getClientIp } from "@/lib/finanzasAuth";
import { registrarAuditoria } from "@/lib/finanzasAudit";

// ── /api/finanzas/proyectos/[id] — editar / archivar. Solo admin. ──────────

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const role = getFinanzasRole(req);
  if (role !== "admin") return NextResponse.json({ ok: false, error: "forbidden" }, { status: 403 });

  const supabase = getFinanzasSupabase();
  if (!supabase) return NextResponse.json({ ok: false, error: "not_configured" }, { status: 503 });

  const { id } = await ctx.params;
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "bad_request" }, { status: 400 });
  }

  const allowed = ["nombre", "tipo", "propietario_inversion", "descripcion", "recurrente_mensual_mxn", "precio_recuperacion_mensual", "meta_clientes_recuperacion", "activo", "orden"];
  const update: Record<string, unknown> = {};
  for (const k of allowed) if (k in body) update[k] = body[k];

  if (Object.keys(update).length === 0) {
    return NextResponse.json({ ok: false, error: "nothing_to_update" }, { status: 400 });
  }

  const { data, error } = await supabase
    .from("finanzas_proyectos")
    .update(update)
    .eq("id", id)
    .select()
    .single();

  if (error) return NextResponse.json({ ok: false, error: error.message }, { status: 500 });

  await registrarAuditoria(supabase, {
    persona: getFinanzasPersona(req),
    accion: "editar",
    entidad: "proyecto",
    entidad_id: id,
    detalle: data.nombre,
    ip: getClientIp(req),
  });

  return NextResponse.json({ ok: true, proyecto: data });
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const role = getFinanzasRole(req);
  if (role !== "admin") return NextResponse.json({ ok: false, error: "forbidden" }, { status: 403 });

  const supabase = getFinanzasSupabase();
  if (!supabase) return NextResponse.json({ ok: false, error: "not_configured" }, { status: 503 });

  const { id } = await ctx.params;
  // No se borra físicamente si tiene movimientos ligados: se archiva (activo=false)
  // para no romper la integridad referencial del histórico.
  const { count } = await supabase
    .from("finanzas_movimientos")
    .select("id", { count: "exact", head: true })
    .eq("proyecto_id", id);

  const { data: proy } = await supabase.from("finanzas_proyectos").select("nombre").eq("id", id).maybeSingle();

  if (count && count > 0) {
    const { data, error } = await supabase
      .from("finanzas_proyectos")
      .update({ activo: false })
      .eq("id", id)
      .select()
      .single();
    if (error) return NextResponse.json({ ok: false, error: error.message }, { status: 500 });

    await registrarAuditoria(supabase, {
      persona: getFinanzasPersona(req),
      accion: "archivar",
      entidad: "proyecto",
      entidad_id: id,
      detalle: proy?.nombre || "",
      ip: getClientIp(req),
    });

    return NextResponse.json({ ok: true, archivado: true, proyecto: data });
  }

  const { error } = await supabase.from("finanzas_proyectos").delete().eq("id", id);
  if (error) return NextResponse.json({ ok: false, error: error.message }, { status: 500 });

  await registrarAuditoria(supabase, {
    persona: getFinanzasPersona(req),
    accion: "eliminar",
    entidad: "proyecto",
    entidad_id: id,
    detalle: proy?.nombre || "",
    ip: getClientIp(req),
  });

  return NextResponse.json({ ok: true, archivado: false });
}
