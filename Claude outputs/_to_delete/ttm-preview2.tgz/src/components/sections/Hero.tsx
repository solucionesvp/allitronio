"use client";

import { useCallback, useEffect, useRef } from "react";
import {
  motion,
  useAnimationFrame,
  useMotionValue,
  useSpring,
  useTransform,
  useReducedMotion,
  useScroll,
  type MotionValue,
} from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { OptionalImage } from "@/components/media/OptionalAsset";
import { HERO } from "@/config/assets";
import AlliGuide from "@/components/brand/AlliGuide";
import FilmGrain from "@/components/effects/FilmGrain";

// ── Animation helpers ────────────────────────────────────────────
// ── Node graph data ──────────────────────────────────────────────
interface Satellite {
  x: number;   // 0–1 normalized within the graph container
  y: number;
  delay: number;
  orange?: boolean;
}

// Satellites: intentionally asymmetric, not a simple circle pattern.
// Densificado — el grafo original (7 nodos) se sentía disperso frente al
// resto del sitio; ahora tiene la misma densidad de malla que AllitronGraph.
const SATELLITES: Satellite[] = [
  { x: 0.16, y: 0.18, delay: 0.0  },
  { x: 0.60, y: 0.10, delay: 0.35 },
  { x: 0.88, y: 0.36, delay: 0.7  },
  { x: 0.84, y: 0.70, delay: 0.55 },
  { x: 0.40, y: 0.86, delay: 0.9  },
  { x: 0.06, y: 0.60, delay: 0.18 },
  { x: 0.46, y: 0.44, delay: 0.45, orange: true }, // inner node, no hub connection
  { x: 0.30, y: 0.42, delay: 0.25 },
  { x: 0.70, y: 0.55, delay: 0.6  },
  { x: 0.24, y: 0.75, delay: 0.15 },
  { x: 0.92, y: 0.15, delay: 0.5  },
  { x: 0.55, y: 0.28, delay: 0.8  },
  { x: 0.10, y: 0.40, delay: 0.35 },
];

// Ambient dots — sin conexión al hub, solo densidad de fondo (mismo
// recurso que el campo de partículas de AllitronGraph/engine.ts).
const AMBIENT_DOTS: { x: number; y: number; delay: number }[] = [
  { x: 0.50, y: 0.06, delay: 0.2 },
  { x: 0.76, y: 0.24, delay: 0.9 },
  { x: 0.96, y: 0.55, delay: 0.4 },
  { x: 0.66, y: 0.92, delay: 1.1 },
  { x: 0.14, y: 0.94, delay: 0.6 },
  { x: 0.02, y: 0.30, delay: 1.3 },
  { x: 0.34, y: 0.60, delay: 0.8 },
  { x: 0.58, y: 0.68, delay: 0.3 },
  { x: 0.80, y: 0.82, delay: 1.0 },
  { x: 0.20, y: 0.06, delay: 0.5 },
];

const HUB_CONNECTIONS = [0, 1, 2, 3, 4, 5, 7, 10, 11] as const; // SATELLITES indices
const SAT_CONNECTIONS: [number, number][] = [
  [0, 1], [1, 2], [2, 3], [3, 6], [4, 6], [5, 0],
  [7, 6], [8, 3], [9, 4], [12, 5], [8, 10], [9, 7],
];

// Aristas con pulso viajero — refuerzan la sensación de "energía"
// circulando por la red, igual que las aristas energizadas del motor
// Canvas usado en el resto del sitio.
const PULSE_SATELLITES = [1, 4, 10] as const; // subset of HUB_CONNECTIONS
const PULSE_SPEEDS = [2.4, 3.1, 2.7]; // segundos por recorrido
const PULSE_PHASES = [0, 0.34, 0.68]; // desfase inicial [0–1]

// ── NodeGraph ────────────────────────────────────────────────────
// Fallback del visual del hero — se muestra si HERO.visualVideo (Higgsfield)
// todavía no existe en public/ (ver bloque "Hero visual" más abajo). No se
// elimina: es el estado seguro mientras el asset generado no está en el repo.
interface NodeGraphProps {
  rawMouseX: MotionValue<number>;
  rawMouseY: MotionValue<number>;
  reduced: boolean;
}

function NodeGraph({ rawMouseX, rawMouseY, reduced }: NodeGraphProps) {
  const svgRef    = useRef<SVGSVGElement>(null);
  const hubRef    = useRef<SVGCircleElement>(null);
  const hubGlowRef = useRef<SVGCircleElement>(null);
  const hubGlowOuterRef = useRef<SVGCircleElement>(null);

  // One ref slot per hub-satellite line
  const lineRefs = useRef<(SVGLineElement | null)[]>(
    Array(HUB_CONNECTIONS.length).fill(null) as (SVGLineElement | null)[],
  );

  // One ref slot per traveling pulse dot
  const pulseRefs = useRef<(SVGCircleElement | null)[]>(
    Array(PULSE_SATELLITES.length).fill(null) as (SVGCircleElement | null)[],
  );

  // Cache SVG dimensions to avoid per-frame getBoundingClientRect
  const dims = useRef({ w: 0, h: 0 });
  useEffect(() => {
    const update = () => {
      if (!svgRef.current) return;
      const r = svgRef.current.getBoundingClientRect();
      dims.current = { w: r.width, h: r.height };
    };
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  // Hub follows mouse with heavy spring — slow, weighted, intentional
  const hubNormX = useTransform(rawMouseX, [0, 1], [0.32, 0.68]);
  const hubNormY = useTransform(rawMouseY, [0, 1], [0.30, 0.70]);
  const hubSpringX = useSpring(hubNormX, { stiffness: 26, damping: 34, mass: 1.6 });
  const hubSpringY = useSpring(hubNormY, { stiffness: 26, damping: 34, mass: 1.6 });

  // Imperatively update hub + dynamic lines without re-renders
  useAnimationFrame((time) => {
    if (reduced) return;
    const { w, h } = dims.current;
    if (w === 0 || h === 0) return;

    const hx = hubSpringX.get() * w;
    const hy = hubSpringY.get() * h;

    hubRef.current?.setAttribute("cx", String(hx));
    hubRef.current?.setAttribute("cy", String(hy));
    hubGlowRef.current?.setAttribute("cx", String(hx));
    hubGlowRef.current?.setAttribute("cy", String(hy));
    hubGlowOuterRef.current?.setAttribute("cx", String(hx));
    hubGlowOuterRef.current?.setAttribute("cy", String(hy));

    HUB_CONNECTIONS.forEach((satIdx, lineIdx) => {
      const line = lineRefs.current[lineIdx];
      if (!line) return;
      const sat = SATELLITES[satIdx];
      line.setAttribute("x1", String(hx));
      line.setAttribute("y1", String(hy));
      line.setAttribute("x2", String(sat.x * w));
      line.setAttribute("y2", String(sat.y * h));
    });

    // Traveling pulses — un punto de luz recorriendo hub→satélite en loop,
    // dando la sensación de energía circulando por la red.
    PULSE_SATELLITES.forEach((satIdx, i) => {
      const pulse = pulseRefs.current[i];
      if (!pulse) return;
      const sat = SATELLITES[satIdx];
      const tRaw = (time / 1000 / PULSE_SPEEDS[i] + PULSE_PHASES[i]) % 1;
      const px = hx + (sat.x * w - hx) * tRaw;
      const py = hy + (sat.y * h - hy) * tRaw;
      pulse.setAttribute("cx", String(px));
      pulse.setAttribute("cy", String(py));
      pulse.setAttribute("opacity", String(Math.sin(tRaw * Math.PI) * 0.95));
    });
  });

  return (
    <svg
      ref={svgRef}
      aria-hidden="true"
      className="absolute inset-0 h-full w-full"
    >
      <defs>
        <radialGradient id="graphHubGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#09AFF2" stopOpacity="0.32" />
          <stop offset="100%" stopColor="#09AFF2" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="graphHubGlowOuter" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#09AFF2" stopOpacity="0.14" />
          <stop offset="100%" stopColor="#09AFF2" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* Ambient background particles — densidad de fondo, sin conexión */}
      {AMBIENT_DOTS.map((dot, idx) => (
        <circle
          key={`ambient-${idx}`}
          cx={`${dot.x * 100}%`}
          cy={`${dot.y * 100}%`}
          r="1"
          fill="rgba(9,175,242,0.35)"
          className="animate-node-breathe"
          style={{ animationDelay: `${dot.delay}s` }}
        />
      ))}

      {/* Satellite ↔ satellite connections (static) */}
      {SAT_CONNECTIONS.map(([a, b], idx) => {
        const sa = SATELLITES[a];
        const sb = SATELLITES[b];
        return (
          <line
            key={`ss-${idx}`}
            x1={`${sa.x * 100}%`}
            y1={`${sa.y * 100}%`}
            x2={`${sb.x * 100}%`}
            y2={`${sb.y * 100}%`}
            stroke="rgba(9,175,242,0.13)"
            strokeWidth="0.5"
          />
        );
      })}

      {/* Hub → satellite connections (dynamic via refs) */}
      {HUB_CONNECTIONS.map((satIdx, lineIdx) => {
        const sat = SATELLITES[satIdx];
        return (
          <line
            key={`hl-${lineIdx}`}
            ref={(el) => {
              lineRefs.current[lineIdx] = el;
            }}
            stroke="rgba(9,175,242,0.22)"
            strokeWidth="0.6"
            x1="50%"
            y1="50%"
            x2={`${sat.x * 100}%`}
            y2={`${sat.y * 100}%`}
          />
        );
      })}

      {/* Satellite nodes */}
      {SATELLITES.map((sat, idx) => (
        <circle
          key={`sat-${idx}`}
          cx={`${sat.x * 100}%`}
          cy={`${sat.y * 100}%`}
          r={sat.orange ? "2.5" : "2"}
          fill={sat.orange ? "#F2874C" : "rgba(9,175,242,0.68)"}
          className={sat.orange ? "" : "animate-node-breathe"}
          style={{ animationDelay: `${sat.delay}s` }}
        />
      ))}

      {/* Traveling pulses — energía circulando hub→satélite (ref-updated) */}
      {!reduced &&
        PULSE_SATELLITES.map((_, i) => (
          <circle
            key={`pulse-${i}`}
            ref={(el) => {
              pulseRefs.current[i] = el;
            }}
            r="2"
            fill="#F5F7F8"
            opacity="0"
          />
        ))}

      {/* Hub ambient glow — dos capas (ref-updated) */}
      <circle ref={hubGlowOuterRef} cx="50%" cy="50%" r="46" fill="url(#graphHubGlowOuter)" />
      <circle ref={hubGlowRef} cx="50%" cy="50%" r="24" fill="url(#graphHubGlow)" />

      {/* Hub organizer node (ref-updated) */}
      <circle ref={hubRef} cx="50%" cy="50%" r="4.5" fill="#09AFF2" opacity="0.92" />
    </svg>
  );
}

// ── Pillars ──────────────────────────────────────────────────────
const PILLARS = ["TECNOLOGÍA", "INTELIGENCIA ARTIFICIAL", "ESTRATEGIA"] as const;

// ── Hero ─────────────────────────────────────────────────────────
export default function Hero() {
  const shouldReduceMotion = useReducedMotion();
  const reduced = shouldReduceMotion ?? false;

  // ── Parallax scroll — el único elemento interactivo de scroll del home:
  // el fondo, el grafo y el contenido se mueven a velocidades distintas
  // mientras el hero sale de vista, dando la sensación de profundidad
  // (ref. Cyclemon: un solo efecto de scroll bien ejecutado > mil elementos).
  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  });
  const bgParallaxY = useTransform(scrollYProgress, [0, 1], [0, 110]);
  const graphParallaxY = useTransform(scrollYProgress, [0, 1], [0, 70]);
  const graphParallaxOpacity = useTransform(scrollYProgress, [0, 0.85], [1, 0]);
  const contentParallaxY = useTransform(scrollYProgress, [0, 1], [0, -55]);

  // Normalized mouse position over entire hero section (0–1)
  const rawMouseX = useMotionValue(0.5);
  const rawMouseY = useMotionValue(0.5);

  const handleMouseMove = useCallback(
    (e: React.MouseEvent<HTMLElement>) => {
      const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
      rawMouseX.set((e.clientX - left) / width);
      rawMouseY.set((e.clientY - top) / height);
    },
    [rawMouseX, rawMouseY],
  );

  return (
    <section
      ref={heroRef}
      className="relative flex min-h-[100svh] flex-col justify-center overflow-hidden"
      onMouseMove={handleMouseMove}
    >
      {/* ── Background layers ───────────────────────────────────── */}
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={reduced ? undefined : { y: bgParallaxY }}
      >
        {/* L1: Base */}
        <div className="absolute inset-0 bg-allitron-base" />

        {/* L2: Subtle technical grid */}
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "linear-gradient(rgba(9,175,242,1) 1px,transparent 1px)," +
              "linear-gradient(90deg,rgba(9,175,242,1) 1px,transparent 1px)",
            backgroundSize: "80px 80px",
            opacity: 0.022,
          }}
        />

        {/* L3: Blue ambient glow — anchored to left, creates depth contrast */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse 50% 50% at 8% 55%, rgba(3,64,88,0.72) 0%, transparent 65%)",
          }}
        />

        {/* L4: Orange accent — top-right, single restrained point */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse 22% 14% at 93% 7%, rgba(242,135,76,0.06) 0%, transparent 55%)",
          }}
        />
      </motion.div>

      {/* ── Hero visual — foto fija (HERO.hero, foto original sin recortes).
          23-sep-2026, corrección final de Lups: NO es un panel lateral —
          es portada completa (pantalla completa), la foto cubre TODA la
          sección, de fondo, detrás del texto también. Notar que el H1 real
          de abajo dice literalmente "CONECTANDO EL FUTURO" — las MISMAS
          palabras que el neón horneado en la foto — así que el neón de la
          foto funciona como eco/textura detrás del titular real, no como
          algo que había que esconder (ese nunca fue el pedido; el bug
          original era la "O" tapando la CARA de Alli, un choque de
          composición puntual, ya resuelto moviendo el encuadre).
          object-position 72% (móvil 85%, un encuadre más cerrado porque el
          contenedor es angosto) dejó a Alli completo y de buen tamaño, con
          la catedral detrás, en todos los anchos probados (1024 a 2560px).
          Encima va un degradado LINEAL oscuro→transparente: arranca muy
          oscuro (0.94) justo en el borde y va aclarando sin pausa (sin
          tramo plano) hasta transparente ~60% — "vaya aclarándose" en vez
          de quedarse oscuro parejo y cortar de golpe. Y FilmGrain (23-sep,
          mismo pedido) le pone grano fino a toda la foto — móvil y desktop
          — para que no se sienta como un recorte digital "duro". Si el
          archivo aún no existe, OptionalImage cae al NodeGraph. */}
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-25 lg:opacity-100"
        style={reduced ? undefined : { y: graphParallaxY, opacity: graphParallaxOpacity }}
      >
        <OptionalImage
          src={HERO.hero}
          alt=""
          loading="eager"
          className="h-full w-full object-cover object-[85%_center] lg:object-[72%_center]"
          fallback={
            <NodeGraph rawMouseX={rawMouseX} rawMouseY={rawMouseY} reduced={reduced} />
          }
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 hidden
            lg:block lg:bg-[linear-gradient(to_right,rgba(16,24,32,0.94)_0%,rgba(16,24,32,0)_60%)]"
        />
        <FilmGrain opacity={0.1} />
      </motion.div>

      {/* Velo oscuro extra en móvil — el video vive detrás de todo el
          contenido ahí (no solo a la derecha como en desktop), así que
          necesita más contraste para que el texto siga siendo legible. */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-gradient-to-b from-allitron-base/60 via-allitron-base/75 to-allitron-base lg:hidden"
      />

      {/* ── Main content — desplaza a velocidad distinta del fondo,
          creando la sensación de profundidad al hacer scroll ────── */}
      <motion.div
        className="relative z-10 mx-auto w-full max-w-[1440px] px-6 pb-16 pt-28 sm:px-8 sm:pt-32 lg:px-16 xl:px-24 2xl:px-32"
        style={reduced ? undefined : { y: contentParallaxY }}
      >
        <div className="max-w-[520px] lg:max-w-[600px] xl:max-w-[660px]">

          {/* Eyebrow */}
          <p
            className="rise-in mb-6 font-display text-[0.58rem] font-semibold tracking-[0.44em] text-allitron-blue"
            style={{ animationDelay: "0s" }}
          >
            NAYARIT · MÉXICO
          </p>

          {/* Title */}
          <h1
            className="font-display font-black leading-[0.9] tracking-tight"
            style={{ fontSize: "clamp(2.9rem, 7vw, 6.5rem)" }}
          >
            <span
              className="rise-in block text-foreground"
              style={{ animationDelay: "0.12s" }}
            >
              CONECTANDO
            </span>
            <span
              className="rise-in block text-allitron-blue"
              style={{ animationDelay: "0.22s" }}
            >
              EL FUTURO.
            </span>
          </h1>

          {/* Editorial separator */}
          <div
            className="fade-in mt-8 h-px w-10 bg-allitron-blue/35"
            style={{ animationDelay: "0.35s" }}
          />

          {/* Description */}
          <p
            className="fade-in mt-6 max-w-[390px] font-body text-[0.875rem] leading-[1.85] text-muted sm:text-[0.92rem]"
            style={{ animationDelay: "0.44s" }}
          >
            Tecnología, inteligencia artificial y estrategia para transformar
            empresas, conectar talento y acelerar la adopción del futuro.
          </p>

          {/* CTAs */}
          <div
            className="fade-in mt-10 flex flex-wrap gap-4"
            style={{ animationDelay: "0.57s" }}
          >
            <a
              href="#allitron"
              className="inline-flex items-center gap-2 bg-allitron-blue px-6 py-3 font-display text-[0.62rem] font-bold tracking-[0.2em] text-allitron-base transition-colors duration-300 hover:bg-allitron-blue/85 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-allitron-blue focus-visible:ring-offset-2 focus-visible:ring-offset-allitron-base sm:px-7 sm:py-3.5"
            >
              EXPLORAR ALLITRON
              <ArrowUpRight className="h-3.5 w-3.5 shrink-0" strokeWidth={2.5} />
            </a>
            <a
              href="#hub"
              className="inline-flex items-center border border-white/[0.11] px-6 py-3 font-display text-[0.62rem] font-semibold tracking-[0.2em] text-muted transition-all duration-300 hover:border-white/22 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/20 focus-visible:ring-offset-2 focus-visible:ring-offset-allitron-base sm:px-7 sm:py-3.5"
            >
              CONOCER EL HUB
            </a>
          </div>
        </div>

        {/* Pillars */}
        <div
          className="fade-in mt-14 flex flex-wrap items-center gap-y-3 lg:mt-20"
          style={{ animationDelay: "0.74s" }}
        >
          {PILLARS.map((pillar, idx) => (
            <div key={pillar} className="flex items-center">
              {idx > 0 && (
                <div className="mx-7 h-3 w-px bg-white/10" aria-hidden="true" />
              )}
              <span className="font-display text-[0.52rem] font-bold tracking-[0.35em] text-muted/45">
                {pillar}
              </span>
            </div>
          ))}
        </div>
      </motion.div>

      {/* ── Fundido de salida — continúa hacia Soluciones sin corte duro,
          el gradiente ya cierra en negro (#050708), mismo tono con el que
          arranca la siguiente sección. ──────────────────────────────── */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 bottom-0 h-32 bg-gradient-to-b from-transparent to-[#050708]"
      />

      {/* Alli marca la primera transición del recorrido (Hero → resto del
          home) — completa el patrón que ya existe en Solutions → Hub →
          Footer (ver AlliGuide), antes solo empezaba a la mitad del scroll. */}
      <AlliGuide variant="primary" side="right" size={76} className="-bottom-8" />
    </section>
  );
}
